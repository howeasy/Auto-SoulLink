# SLink — Player Setup Guide

This package contains everything you need to play a Soul Link Nuzlocke with
SLink in BizHawk. You do **not** need Python — the host handles the server.

---

## What you need

| Requirement | Detail |
|---|---|
| BizHawk 2.9+ | https://github.com/TASEmulators/BizHawk/releases |
| Your ROM | Gen 1 (Red/Blue/Yellow), Gen 2 (Crystal), Gen 3 (FireRed/LeafGreen/Radical Red), Gen 4 (HeartGold/SoulSilver/Platinum), Gen 5 (Black/White/Black 2/White 2) |
| LuaSocket DLL | Already in `lua/x64/`. If missing, see the note below. |
| Launcher script | Download from your host's status page (one click — see Step 1). |

---

## Step 1 — Download your launcher from the host

Your host will share their **status page URL**, which looks like:

```
http://<host-ip>:8080/
```

> **Note:** The URL must use the host's actual LAN/WAN IP address, not
> `127.0.0.1` or `localhost` — those only work on the host's own machine.

On the status page, click the **download button** for your player slot
(Player A or Player B). This gives you a `.lua` file pre-configured with
the correct server address, port, and player ID.

**Save that file into this folder** — the same folder that contains `lua/`
and `data/`. For example:

```
SLink-player-v1.0.0/
├── slink_MyRun_a.lua   ← place the downloaded launcher here
├── lua/
└── data/
```

---

## Step 2 — Load in BizHawk

1. Open BizHawk and load your save file.
2. Open **Tools → Lua Console**.
3. Click **Open Script** and select the launcher `.lua` file you downloaded.
4. The console will print:

   ```
   [SLink] TCP connected to <host>:<port>
   ```

   If it prints `TCP connecting… (non-blocking)` briefly first, that is
   normal — it connects within a second or two.

> **Important:** Load your save file *before* opening the Lua script.
> The script validates save data at startup. If the save isn't loaded yet,
> writes are disabled until validation passes (it retries automatically).

---

## If the LuaSocket DLL is missing

The file `lua/x64/socket-windows-5-4.dll` is required. If it is absent,
copy it from your [Archipelago](https://github.com/ArchipelagoMW/Archipelago/releases)
installation:

```
<Archipelago folder>\data\lua\x64\socket-windows-5-4.dll
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `module 'socket' not found` | `socket-windows-5-4.dll` is missing from `lua/x64/`. See above. |
| `TCP connect failed` / retrying | Server is not running, or IP/port is wrong. Ask host to verify. |
| Connected but nothing happens | Check with host that your player slot (A or B) is not already taken. |
| Writes disabled / validation failed | Load your save file **before** the Lua script. |
| `Wrong save!` on screen | You loaded a different save file than the one registered for your slot. |
| Folder picker appears | Put the launcher `.lua` file inside the extracted `SLink-player-*` folder, next to `lua/`. |

---

## What SLink does automatically

- **Links encounters by area** — your first catch on a route is permanently
  paired with your partner's first catch on the same route.
- **Propagates faints** — when your linked partner faints, so does yours.
- **Dead zones** — if either player fails to catch on a route, both lose
  that slot. Neither linked mon can be used.
- **Memorial box** — dead pairs are moved to a dedicated box after the
  battle ends.

You play normally. SLink enforces the rules for you.
